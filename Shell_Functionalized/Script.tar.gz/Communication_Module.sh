#!/bin/sh
#!/bin/python

#This function will run the Node 
function Node_run() {
	iri=$1
	Method=$2
	if [[ "$Method" == "Run" ]];
	then
		java -jar $iri -p 14265 &
	fi
	if [[ "$Method" == "PID" ]];
	then
		process=$(ps ax | grep $iri) #enquires the system for the process id of the iri java 
		for i in ${process[@]};
		do	
			break 
		done
		echo "$i"
	fi
}

#This function generates the seed for the account
function Seed_Generator() {
	#Still needs implementation....
	Communication=$1	
	Module="Seed_Generator"
	output=$(python $Communication "$Module")
	echo "$output"
}

#This function generates a random address when called
function Address_Generator() {
	Communication=$1
	Seed=$2
	Module="Address_Generator"
	output=$(python $Communication "$Module" "$Seed")
	echo "$output"
}

#This function broadcasts the message into the tangle
function Send_Module_Function() {
	Communication=$1
	Receive=$2
	Seed=$3
	Message=$4
	Sender_Address=$5
	Server=$6
	Module="Sender_Module"
	python $Communication "$Module" "$Seed" "$Receive" "$Message" "$Sender_Address" "$Server" &
}

#This function will run the Receiving module in python
function Receiver_Module_Function() {
	Communication=$1
	Seed=$2
	Server=$3
	Module="Receiver_Module"
	output=$(python $Communication "$Module" "$Seed" "$Server")
	echo "$output"
}
